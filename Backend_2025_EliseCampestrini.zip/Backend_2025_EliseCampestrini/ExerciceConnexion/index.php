<?php

require_once("connexion.php"); // récupérer la connexion à la base de données pour y accéder





if($_POST)
{

    $email = $_POST["email"];
    $password = $_POST["passwordConfirmation"];

    // check de l'email
    $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE email = :email");
        $stmt->execute(['email' => $email]);
        $emails = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($emails))
    {
        echo "Cet email à déjà un compte";
    }
    else
    {
        $sql = "INSERT INTO utilisateurs (email, mot_de_passe) VALUES(:email, :mot_de_passe)";

        $stmt = $pdo->prepare($sql);
        $stmt->execute
        ([
            'email' => $email,
            'mot_de_passe' => password_hash($password, PASSWORD_DEFAULT)
        ]);

        echo "Votre user a été cocrrectement inséré en BDD";
    }

}


?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>

<body>

    <h1>Formulaires</h1>

    <main>
    <section>
        <h2>S'inscrire</h2>

        <ul id="errorInfos" class= "invisible">
        </ul>

        <p id="sucessBox" class="invisible">Formulaire envoyé !</p>

        <form method="POST" id="inscription">

            <div>
                <label for="email">Email</label>
                <input type="email" name="email" id="emailInscription" placeholder="Votre adresse mail">
            </div>
            
            <div>
                <label for="password">Mot de passe</label>
                <input type="password" name="password" id="passwordInscription" placeholder="Votre mot de passe">
            </div>

            <div>
                <label for="passwordConfirmation">Confirmation du mot de passe</label>
                <input type="password" name="passwordConfirmation" id="passwordConfirmation" placeholder="Votre mot de passe">
            </div>
                
            </div>

            <input type="submit" value="S'inscrire" id="submitButtonInscription" class="buttonStyle">
        </form>
    </section>

    </main>
    


    



    <script src="formCheck.js"></script>

</body>


</html>

