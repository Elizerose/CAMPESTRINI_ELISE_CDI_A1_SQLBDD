<?php include 'cardsController.php'; ?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Découvre notre jeu de cartes à collectionner inspiré de l'univers de League of Legends ! Collectionne des cartes, construit des decks et affronte des joueurs du monde entier. Rejoignez l'aventure dès maintenant !">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="img/icons/collection.png"/>
    <link href="https://db.onlinewebfonts.com/c/12420e8c141ca7c3dff41de2d59df13e?family=Beaufort+for+LOL+Bold" rel="stylesheet"> 
    <link href="https://db.onlinewebfonts.com/c/12420e8c141ca7c3dff41de2d59df13e?family=Beaufort+for+LOL+Light" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" /> <!-- Swiper js -->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/form.css">
    <link rel="stylesheet" href="../css/profile.css">
    <link rel="stylesheet" href="../css/cards.css">

    <title>League Of Legends TCG - Collectionne, Échange, Combat !</title>


</head>
<body>

        <!-- HEADER -->
        <header>
			<!-- On ajoute notre header -->
			<?php include '../includes/header.php'; ?>
		</header>

        <h1>Ma Page / Création de cartes</h1>
        <h3>Exercice CRUD</h3>

        <h2>Créer votre propre carte ! </h2>

        <!---------------------------------------------- FORMULAIRE---------------------------------------------------->

        <section class = "formulaires">

        <form method="POST" id="createCardForm" enctype="multipart/form-data" class="form_class">
            <div class="displayFlex">
                <div>
                    <div>
                        <label for="cardName">Nom de la carte</label>
                        <?php 
                        
                        if ($edit_id != null) 
                        {
                            echo "<input type='text' name='cardName' id='cardName' placeholder='Nom de la carte'required value='". $card_edit['card_name'] ."'>";
                        } else
                        {
                            echo "<input type='text' name='cardName' id='cardName' placeholder='Nom de la carte'required>";
                        }
             
                        ?>
                    </div>

                    <div>
                        <label for="cardTitle">Titre de la carte</label>

                        <?php 
                        
                        if ($edit_id != null) 
                        {
                            echo "<input type='text' name='cardTitle' id='cardTitle' placeholder='Titre de la carte' value='". $card_edit['card_title'] ."'>";
                        } else
                        {
                            echo "<input type='text' name='cardTitle' id='cardTitle' placeholder='Titre de la carte'>";
                        }
             
                        ?>
                        
                    </div>
                    
                    <div>
                        <label for="cardDesc">Description de la carte</label>
                        
                        <?php 
                        
                        if ($edit_id != null) 
                        {
                            echo "<textarea name='cardDesc' id='cardDesc' rows='4' cols='50' placeholder='Description de la carte..' required>". $card_edit['card_description'] ."</textarea>";
                        } else
                        {
                            echo "<textarea name='cardDesc' id='cardDesc' rows='4' cols='50' placeholder='Description de la carte..' required></textarea>";
                        }
             
                        ?>
                        
                    </div>
                </div>
                <div>
                    <div>
                        <label for="card_color">Couleur de la carte :</label>
                        <?php 
                        
                        if ($edit_id != null) 
                        {
                            echo "<input type='text' id='card_color' name='card_color' maxlength='7' placeholder='#FFFFFF' value='". $card_edit['card_color'] ."' required>";
                        } else
                        {
                            echo "<input type='text' id='card_color' name='card_color' maxlength='7' placeholder='#FFFFFF' required>";
                        }
             
                        ?>

                    </div>
                    <div>
                        

                        <?php 
                        if ($edit_id != null) 
                        {
                            echo "<label for='card_img'>Choisir une autre image :</label>";
                            echo "<input type='file' id='card_img' name='card_img' accept='image/*' placeholder='choisir une image'>";
                            
                        }
                        else
                        {
                            echo "<label for='card_img'>Choisir une image :</label>";
                            echo "<input type='file' id='card_img' name='card_img' accept='image/*' placeholder='choisir une image' required>";
                        }
                        
             
                        ?>
                        
                    </div>
                    <div id="div_img_edit">
                       
                    <?php 
                        
                        if ($edit_id != null) 
                        {
                            echo "<p>ancienne image</p>";
                            echo "<img src='data:image;base64," . base64_encode($card_edit['card_img']) . "' alt='Image' id='edit_img'>";
                        } 
             
                        ?>

                    </div>
                </div>

            </div>
                
            <?php 
                        
                if ($edit_id != null) 
                {
                    echo "<input type='submit' value='Modifier la carte' id='create' class='buttonStyle' name = 'form_action'>";
                } 
                else 
                {
                    echo "<input type='submit' value='Créer la carte' id='create' class='buttonStyle' name = 'form_action'>";
                }
             
            ?>
                
                    

            
        </form>

        </section>
        
         <!---------------------------------------------- LISTING DES CARTES ---------------------------------------------------->
        <br><br>
        <h2>Cartes crées par les utilisateurs :</h2>
        <br><br>

        <section id="filter_created_cards">
            <form method="GET">
                <button type="submit" name="filter" value="my_cards">Mes cartes</button>
                <button type="submit" name="filter" value="recent">Récent</button>
                <button type="submit" name="filter" value="all">Tout</button>
            </form>
        </section>

        

        <section class="card_list_section">
            
            <?php
                foreach ($cards as $key => $card) 
                {

                    $stmtUser = $pdo->prepare("SELECT pseudo FROM users WHERE id = ?");
                    $stmtUser->execute([$card['id_user']]);
                    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);

                    echo "

                        <div class='champ_infos_card' style='background-color: " . $card['card_color'] . "'>

                            <img src='data:image;base64," . base64_encode($card['card_img']) . "' alt='Image'>

                            <div class='displayFlex infos_card'>
                                <div>
                                    <p class='champ_infos_Name'>". $card["card_name"] ."</p>
                                    <p class='champ_infos_Title'>". $card["card_title"] ."</p>

                                    <p class='champ_infos_Desc'>". $card["card_description"] ."</p>

                                    
                                </div>
                                
                            </div>

                            ";
                            if ($user["pseudo"] == $_SESSION["pseudo"]) // c'est notre carte
                            {
                                echo "<p class='user'> crée par vous </p>
                                <div class='displayFlex action_div'>
                                    <a href='?edit_id=" . $card['card_id'] ."'>
                                    <i class='fa-solid fa-pen' style='color: #4b1616;'></i>
                                    </a>
                                    
                                    <i class='fa-solid fa-trash' style='color: #4b1616;' onclick='DeleteConfirmation(". $card['card_id'] .")' style='cursor: pointer;'></i>
                                </div>
                                ";
                            }
                            else
                            {
                                echo "<p class='user' > crée par ". $user['pseudo'] ."</p>";
                            }
                            
                        echo "
                        </div>
                    ";
  
                }

            ?>
        </section>
    
        <?php include '../profile.php'; ?>

    </body>
</html>


<script>

    function DeleteConfirmation(cardId) 
    {
        let confirmation = window.confirm("Voulez-vous vraiment supprimer cette carte ?");
        if (confirmation) 
        {
            window.location.href = "?delete_id=" + cardId;
        } else 
        {
            console.log("Suppression annulée.");
        }
    }

</script>

<script src="https://kit.fontawesome.com/c2ae8767dc.js" crossorigin="anonymous"></script>