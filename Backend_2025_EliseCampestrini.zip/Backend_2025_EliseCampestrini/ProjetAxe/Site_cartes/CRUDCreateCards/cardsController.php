<?php
// on appelle notre connexion a notre bdd
require_once("../src/connexion.php");
// -------------------------------------------- FILTRES --------------------------------------------------

// Si on a un filtre d'affichage de cartes
$filter = isset($_GET['filter']) ? $_GET['filter'] : '';

// Préparer la requête SQL en fonction du filtre
if ($filter == 'my_cards') {
    // Si l'utilisateur veut voir ses cartes, on filtre par son id
    $stmt = $pdo->prepare("SELECT * FROM cards WHERE id_user = :id_user");
    $stmt->execute(['id_user' => $_SESSION["id_user"]]);
} 
else if ($filter == 'recent') 
{
    // Si l'utilisateur veut voir les cartes récentes, on trie par date
    $stmt = $pdo->prepare("SELECT * FROM cards ORDER BY date DESC");
    $stmt->execute();
}
else
{
    // recuperer toutes nos cartes pour les afficher
    $stmt = $pdo->query("SELECT * FROM cards"); // PDO STATEMENT
}

$cards = $stmt->fetchAll(PDO::FETCH_ASSOC);

// -------------------------------------------- EDIT CARDS --------------------------------------------------

// Si on est en mode edit

$edit_id = isset($_GET['edit_id']) ? $_GET['edit_id'] : '';
if ($edit_id != null)
{
    $stmt = $pdo->prepare("SELECT * FROM cards WHERE card_id = $edit_id");
    $stmt->execute();
    $card_edit = $stmt->fetch(PDO::FETCH_ASSOC);
}

$delete_id = isset($_GET['delete_id']) ? $_GET['delete_id'] : '';
if ($delete_id != null)
{
    $stmt = $pdo->prepare("DELETE FROM cards WHERE card_id = $delete_id");
    $stmt->execute();
}



// Si on a un formulaire envoyé
if ($_POST)
{

    // On recupere nos champs
    $card_name = $_POST["cardName"];
    $card_title = $_POST["cardTitle"];
    $card_description = $_POST["cardDesc"];
    $card_color = $_POST["card_color"];
    $card_img = $_FILES["card_img"];
    $id_user = $_SESSION["id_user"];

    

    date_default_timezone_set('Europe/Paris'); // on definit le fuseau horaire à Paris
    $date = date('Y-m-d H:i:s');


    if ($card_edit != null)
    {
        $part = "";
        if ($card_edit['card_name'] != $card_name)
        {
            if ($part != "")
            {
                $part .= ",";
            }
            // on ajoute notre bout de requete correspondant dans notre part temporaire
            $part .= " card_name = :card_name";
            // On ajoute dans notre variable le parametre correspondant
            $updateParams['card_name'] = $card_name;
        }
        if ($card_edit['card_title'] != $card_title)
        {
            if ($part != "")
            {
                $part .= ",";
            }
            // on ajoute notre bout de requete correspondant dans notre part temporaire
            $part .= " card_title = :card_title";
            // On ajoute dans notre variable le parametre correspondant
            $updateParams['card_title'] = $card_title;
        }
        if ($card_edit['card_description'] != $card_description)
        {
            if ($part != "")
            {
                $part .= ",";
            }
            // on ajoute notre bout de requete correspondant dans notre part temporaire
            $part .= " card_description = :card_description";
            // On ajoute dans notre variable le parametre correspondant
            $updateParams['card_description'] = $card_description;
        }
        if ($card_edit['card_color'] != $card_color)
        {
            if ($part != "")
            {
                $part .= ",";
            }
            // on ajoute notre bout de requete correspondant dans notre part temporaire
            $part .= " card_color = :card_color";
            // On ajoute dans notre variable le parametre correspondant
            $updateParams['card_color'] = $card_color;
        }
        if ($card_edit['card_img'] != $card_img && $_FILES['card_img']['error'] != UPLOAD_ERR_NO_FILE)
        {
            $image_data = file_get_contents($_FILES["card_img"]["tmp_name"]);
            if ($part != "")
            {
                $part .= ",";
            }
            // on ajoute notre bout de requete correspondant dans notre part temporaire
            $part .= " card_img = :card_img";
            // On ajoute dans notre variable le parametre correspondant
            $updateParams['card_img'] = $image_data;
        }

        if ($part != null)
        {
            $sql = "UPDATE cards SET $part WHERE card_id = $edit_id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($updateParams);
        }
    }

       
    // Sinon on est en ajout de carte
    // -------------------------------------------- AJOUT DE CARTES --------------------------------------------------

    else 
    {
        
        $image_data = file_get_contents($_FILES["card_img"]["tmp_name"]);
        // On prepare notre commande SQL : on insert dans notre table users le pseudo, email et password récupérés dans les champs
        $sql = "INSERT INTO cards (card_name, card_title, card_img, card_description, card_color, id_user, date) VALUES(:card_name, :card_title, :card_img, :card_description, :card_color, :id_user, :date)";
        
        // on prepare la requête et l'execute
        $stmt = $pdo->prepare($sql);
        $stmt->execute
        ([
            'card_name' => $card_name,
            'card_title' => $card_title,
            'card_img' => $image_data ,
            'card_description' => $card_description,
            'card_color' => $card_color,
            'id_user' => $id_user,
            'date'=> $date
        ]);

        
    }

    header("Location: " . $_SERVER['PHP_SELF']);


}

?>