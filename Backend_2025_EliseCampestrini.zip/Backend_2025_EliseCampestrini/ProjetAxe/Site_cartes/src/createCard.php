
<?php

// Fonction qui affiche un template de carte du champion passé en parametre, canclick si on peut cliquer sur la carte pour etre rediriger vers sa page
function CreateCard($champ,$canclick)
{
    if ($canclick)
    {
        echo "<a href='infos.php?page=" .$champ['id'] ."' class='card'> ";
    }
    echo "
            <div class='champ_infos_card'>
                <img src='https://ddragon.leagueoflegends.com/cdn/img/champion/splash/" .$champ['id'] ."_0.jpg' alt='Elise'>

                <div class='displayFlex infos_card'>
                    <div>
                        <p class='champ_infos_Name'>".$champ['id'] ."</p>
                        <p class='champ_infos_Title'>".$champ['title'] ."</p>
                    </div>
                    <div>
                        <ul class='champ_infos_Tags displayFlex'>
                            " ;
                                foreach ($champ['tags'] as $tag)
                                {
                                    echo "<li><img src='img/icons/role_icon_" .$tag .".png' alt=''></li>";
                                }
                            echo "

                        </ul>
                    </div>
                    
                </div>

            </div>
        

        ";
    if ($canclick)
    {
        echo "</a>";
    }
}

?>