<?php
include 'api.php';
include 'createCard.php';

$champToDisplay = []; // liste des champions a afficher

    // Si on get le filter dans l'url
    $filter = $_GET['filter'] ?? null;
    $search = $_GET['search'] ?? null; 


    // On parcours tous les champions 
    foreach ($AllChamps as $champions)
    {
        // On initialise les variables
        $isInFilter = false; 
        $isInSearch = false;

        // Si il y a un parametre de filtre (par role/tags)
        if ($filter) 
        {
            // On parcours les tags du champion et les compare au filtre
            foreach ($champions['tags'] as $tag) 
            {
                if ($tag == $filter) 
                {
                    $isInFilter = true; // si il correspond on passe la variable a true
                    break;
                }
            }
        } 
        // Si il n'y a pas de parametre filtre on passe la variable a true car on prend tt les champions
        else 
        {
            $isInFilter = true; 
        }

        // Si il y a un parametre de Recherche
        if ($search) 
        {
            if (stripos($champions['id'], $search) === 0) // la fonction stripos retourne l'index ou il trouve le search dans le mot et est insensible a la casse. On FAIT !== car si la fonction retourne 0, c'est considéré comme false alors que c'est l'index qquil retourne donc ca doit etre true. On ne peut pas faire != mais !==
            {
                $isInSearch = true;
            }
        }
        else 
        {
            $isInSearch = true; 
        }

        // Si les deux conditions sont OK pour le champion, on l'ajoute a la liste a afficher
        if ($isInFilter && $isInSearch) 
        {
            array_push($champToDisplay, $champions);
        }
        
    }

    // On parcours tous les champions qui sont dans la liste à afficher et on les affiche
    foreach ($champToDisplay as $champ)
    {
        CreateCard($champ,TRUE);
    }



?>