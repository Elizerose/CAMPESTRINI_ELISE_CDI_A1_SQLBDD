<?php

require __DIR__ . '/../../vendor/autoload.php';
// On utilise __DIR__ pour que le chemin marche pour tt les appels

// Methode 1 :

// use GuzzleHttp\Client;
// $client = new Client();
// $response = $client->request('GET', 'https://ddragon.leagueoflegends.com/cdn/15.7.1/data/fr_FR/champion.json');
// $statusCode = $response->getStatusCode();
// $body = $response->getBody();
// $data = json_decode($body,true);


// Methode 2 :

// On recupere la data de l'api
$url = 'https://ddragon.leagueoflegends.com/cdn/15.7.1/data/fr_FR/champion.json';
$response = file_get_contents($url);
if ($response === FALSE)
{
    http_response_code(500);
    echo json_encode(['error' => 'Erreur lors de la récupération des données.']);
    exit;
}
else 
{
    $data = json_decode($response,true);
}

// list de tous les champions
$AllChamps = [];

// On initialise la liste
foreach ($data['data'] as $champ)
{
    array_push($AllChamps, $champ);
}





