<?php include 'src/api.php'; ?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Découvre notre jeu de cartes à collectionner inspiré de l'univers de League of Legends ! Collectionne des cartes, construit des decks et affronte des joueurs du monde entier. Rejoignez l'aventure dès maintenant !">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="img/icons/collection.png"/>
    <link href="https://db.onlinewebfonts.com/c/12420e8c141ca7c3dff41de2d59df13e?family=Beaufort+for+LOL+Bold" rel="stylesheet"> 
    <link href="https://db.onlinewebfonts.com/c/12420e8c141ca7c3dff41de2d59df13e?family=Beaufort+for+LOL+Light" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" /> <!-- Swiper js -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/cards.css">
    <title>League Of Legends TCG - Collectionne, Échange, Combat !</title>


</head>

	<body>
		
		<!-- HEADER -->
		<header>

			<!-- On ajoute notre header -->
			<?php include 'includes/header.php'; ?>

		</header>

        <!-- SECTION DE RECHERCHE -->
        <section id="SearchSection">

            <h1>Champions</h1>

            <img src="img/separator/t1HeaderDivider.png" alt="separateur" class="separator">

            <!-- Barre de recherche -->
            <input type="text" id="searchBar" placeholder="Rechercher un champion..." oninput="searchChampion(this.value)"> <!-- oninput pour faire une recherche dynamique-->

            <!-- Boutons de filtres -->
            <ul>
                <li><button onclick="toggleFilter('Mage')" id="Mage"><img src="img/icons/role_icon_mage.png" alt="Mage" title="Mage"></button></li>
                <li><button onclick="toggleFilter('Marksman')" id="Marksman"><img src="img/icons/role_icon_marksman.png" alt="Tireur" title="Tireur"></button></li>
                <li><button onclick="toggleFilter('Fighter')" id="Fighter"><img src="img/icons/role_icon_fighter.png" alt="Combattant" title="Combattant"></button></li>
                <li><button onclick="toggleFilter('Support')" id="Support"><img src="img/icons/role_icon_support.png" alt="Support" title="Support"></button></li>
                <li><button onclick="toggleFilter('Assassin')" id="Assassin"><img src="img/icons/role_icon_assassin.png" alt="Assassin" title="Assassin"></button></li>
                <li><button onclick="toggleFilter('Tank')" id="Tank"><img src="img/icons/role_icon_tank.png" alt="Tank" title="Tank"></button></li>
            </ul>

        </section>


        <!-- Liste des cartes -->
        <section class="card_list_section" id="card_list_section">

            <?php include 'src/display.php'; ?>

        </section>


        <!-- On ajoute notre footer -->
        <?php include 'includes/footer.php'; ?>

    </body>
</html>



<script>

// On stocke les filtres de recherche 
let currentFilter = null; 
let currentSearch = null;

// Fonction qui ajoute le filtre de classes de champions
async function toggleFilter(filter) 
{
    const activeBtn = document.getElementById(filter);
    const filterBtnList = document.querySelectorAll('#SearchSection button');

    // Si on clique sur le filtre déjà actif : on désactive
    if (currentFilter === filter) 
    {
        currentFilter = null; 

        // On retire la classe active de tous les boutons
        filterBtnList.forEach(btn => btn.classList.remove('filter_active'));

        // On recharge toutes les cartes (sans filtre) mais en gardant la recherche
        try 
        {
            const response = await fetch(`src/display.php?search=${currentSearch ?? ''}`);
            const html = await response.text();
            document.getElementById("card_list_section").innerHTML = html;
        } 
        catch (error) 
        {
            console.error("Erreur:", error);
        }

        return; // on sort
    }

    // Sinon, on ajoute le filtre
    currentFilter = filter;

    try 
    {
        // on fetch le lien vers la page php de traitement de filtre et affichage avec nos filtres actuels
        const response = await fetch(`src/display.php?filter=${currentFilter}&search=${currentSearch ?? ''}`);
        // On stock la reponse html dans une variable
        const html = await response.text();
        // on met notre reponse (l'affichage des cartes traitées dans notre display.php) dans notre section de listing de tt les cartes
        document.getElementById("card_list_section").innerHTML = html;
    } 
    catch (error) 
    {
        console.error("Erreur:", error);
    }

    // Met à jour le bouton de filtre
    filterBtnList.forEach(btn => 
    {
        if (btn.id === filter) 
        {
            btn.classList.add('filter_active');
        } 
        else 
        {
            btn.classList.remove('filter_active');
        }
    });
}

// Fonction qui met a jour le filtre de recherche (meme logique qu'au dessus)
async function searchChampion(userInput) 
{
    currentSearch = userInput;
    try {
        const response = await fetch(`src/display.php?filter=${currentFilter ?? ''}&search=${userInput}`);
        if (!response.ok) throw new Error("Erreur lors de la recherche");

        const html = await response.text();
        document.getElementById("card_list_section").innerHTML = html;

    } 
    catch (error) 
    {
        console.error("Erreur:", error);
    }
}


</script>
