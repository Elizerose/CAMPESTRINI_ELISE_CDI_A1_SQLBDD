<?php

// on appelle notre connexion a notre bdd
require_once("src/connexion.php");

// Si l'utilisateur n'est pas connecté, on le redirige a la page de connexion / inscription
if(!isset($_SESSION["id_user"]))
{
    header("location:/Backend_2025_EliseCampestrini/ProjetAxe/Site_cartes/form.php");
    exit();
}

// -------------------------------------------- DECONNEXION --------------------------------------------------

// Si notre $action est appelé (défini) et que c'est égal à la déconnexion
if(isset($_GET["action"]) && $_GET["action"] == "deconnexion") {
    // on vide la session
    unset($_SESSION["id_user"]);
    unset($_SESSION["email"]);
    unset($_SESSION["pseudo"]);
    header("location:form.php"); // redirection sans paramètre
    exit();
}







