<?php

// on appelle notre connexion a notre bdd
require_once("src/connexion.php");

// Si l'utilisateur n'est pas connecté, on le redirige a la page de connexion / inscription
if(!isset($_SESSION["id_user"]))
{
    header("location:form.php");
}

// -------------------------------------------- DECONNEXION --------------------------------------------------

// Si notre $action est appelé (défini) et que c'est égal à la déconnexion
if(isset($_GET["action"]) && $_GET["action"] == "deconnexion") {
    // on vide la session
    unset($_SESSION["id_user"]);
    unset($_SESSION["email"]);
    unset($_SESSION["pseudo"]);
    header("location:form.php"); // redirection sans paramètre
}



echo "Vous etes connecté en tant que " . $_SESSION["pseudo"];
    
?>
    
<a href="?action=deconnexion">Se déconnecter</a>


<?php include 'includes/footer.php' ?>



