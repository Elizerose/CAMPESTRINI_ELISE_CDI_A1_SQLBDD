<?php

require_once("src/connexion.php"); // récupérer la connexion à la base de données pour y accéder

$stmt = $pdo->query("SELECT * FROM users"); // PDO STATEMENT
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Si on a un formulaire envoyé
if ($_POST)
{
    // On regarde si le name de notre champ caché est bien défini
    if  (isset($_POST['form_action']))
    {
        // si oui, on regarde s'il correspond au formulaire d'inscription
        if ($_POST['form_action'] === "S'inscrire")
        {    
            // On recupere nos champs
            $pseudo = $_POST["pseudo"];
            $email = $_POST["email"];
            $password = $_POST["passwordConfirmation"];
        
            // On prepare notre commande SQL : on insert dans notre table users le pseudo, email et password récupérés dans les champs
            $sql = "INSERT INTO users (pseudo, email, password) VALUES(:pseudo, :email, :password)";
            
            // on prepare la requête et l'execute
            $stmt = $pdo->prepare($sql);
            $stmt->execute
            ([
                'pseudo' => $pseudo,
                'email' => $email,
                'password' => password_hash($password, PASSWORD_DEFAULT) // on sécurise notre mot de passe
            ]);
        
            //echo "Votre user a été cocrrectement inséré en BDD";
        }
    // Si notre formulaire correspond à celui de la connection
    else if ($_POST['form_action'] === "Se connecter")
    {
        // On recupere nos champs
        $email = trim($_POST["email"]);
        $password = trim($_POST["password"]);
    
        // Si on a bien les deux infos remplis
        if ($email && $password) 
        {
            // on prepare la requête SQL : on selectionne tt les utilisateurs de notre table et on regarde si l'email correspond
            $stmt = $pdo->query("SELECT * FROM users WHERE email = '$email' ");
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // on a récupéré l'utilisateur correspondant, on verifie si son mot de passe correspond
            if ($user && password_verify($password, $user["password"])) 
            {
                // Tout correspond donc on démarre une session, et on redirige la personne sur l'accueil
                $_SESSION["id_user"] = $user["id"];
                $_SESSION["email"] = $user["email"];
                $_SESSION["pseudo"] = $user["pseudo"];
                header("location:index.php");
            } else {
                //echo "La connexion a échoué !";
            }
    
        }
    }
}

    
}



?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Découvre notre jeu de cartes à collectionner inspiré de l'univers de League of Legends ! Collectionne des cartes, construit des decks et affronte des joueurs du monde entier. Rejoignez l'aventure dès maintenant !">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="img/icons/collection.png"/>
    <link href="https://db.onlinewebfonts.com/c/12420e8c141ca7c3dff41de2d59df13e?family=Beaufort+for+LOL+Bold" rel="stylesheet"> 
    <link href="https://db.onlinewebfonts.com/c/12420e8c141ca7c3dff41de2d59df13e?family=Beaufort+for+LOL+Light" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" /> <!-- Swiper js -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/form.css">
    <title>League Of Legends TCG - Collectionne, Échange, Combat !</title>


</head>


<body>

        <!-- HEADER -->
        <header>
			<!-- On ajoute notre header -->
			<?php include 'includes/header.php'; ?>
		</header>

    <h1>Inscription / Connexion</h1>

    <main>
    <section class="formulaires">
        <h2>S'inscrire</h2>

        <ul id="errorInfos" class= "invisible">
        </ul>

        <p id="sucessBox" class="invisible">Formulaire envoyé !</p>

        <form method="POST" id="inscription"  class="form_class">

        <input type="hidden" name="form_action" value="S'inscrire">

            <div>
                <label for="emailInscription">Email</label>
                <input type="email" name="email" id="emailInscription" placeholder="Votre adresse mail">
            </div>

            <div>
                <label for="pseudo">Nom d'utilisateur</label>
                <input type="text" name="pseudo" id="pseudo" placeholder="Votre nom d'utilisateur">
            </div>
            
            <div>
                <label for="passwordInscription">Mot de passe</label>
                <input type="password" name="password" id="passwordInscription" placeholder="Votre mot de passe">
            </div>

            <div>
                <label for="passwordConfirmation">Confirmation du mot de passe</label>
                <input type="password" name="passwordConfirmation" id="passwordConfirmation" placeholder="Votre mot de passe">
            </div>
                
            </div>

            <input type="submit" value="S'inscrire" id="submitButtonInscription" class="buttonStyle" name = "form_action">
        </form>
    </section>

    <section class = "formulaires">
        <h2>Se connecter</h2>

        <ul id="errorInfos" class= "invisible">
        </ul>

        <p id="sucessBoxConnexion" class="invisible">Connexion réussie !</p>

        <form method="POST" id="connexion"  class="form_class">

            <input type="hidden" name="form_action" value="Se connecter">

            <div>
                <label for="emailConnexion">Email</label>
                <input type="email" name="email" id="emailConnexion" placeholder="Votre adresse mail">
            </div>
            
            <div>
                <label for="passwordConnexion">Mot de passe</label>
                <input type="password" name="password" id="passwordConnexion" placeholder="Votre mot de passe">
            </div>
                
            </div>

            <input type="submit" value="Se connecter" id="submitButtonConnexion" class="buttonStyle">
        </form>
    </section>
    </main>
    

    <?php include 'includes/footer.php' ?>

    <script src="formCheck.js"></script>


    
</body>


</html>

