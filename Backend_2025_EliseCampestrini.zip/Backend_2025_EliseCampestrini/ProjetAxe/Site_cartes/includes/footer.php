  <!-- FOOTER   -->
  <footer>

      <div class="footerRow">
        <div><img src="img/logo.png" alt="logo"></div>
        <div>
          <h4>A propos</h4>
          <br>
          <ul>
            <li><a href="">Nouveautés</a></li>
            <li><a href="">Evènements</a></li>
            <li><a href="">Communauté</a></li>
            <li><a href="">Avis</a></li>
          </ul>
        </div>
        <div>
          <h4>Ressources</h4>
          <br>
          <ul>
            <li><a href="">Aide</a></li>
            <li><a href="">Faq</a></li>
            <li><a href="">Nous contacter</a></li>
            <li><a href="">Devenir affilié</a></li>
          </ul>
        </div>
        <div>
          <h4>Réseaux sociaux</h4>
          <br>
          <ul>
            <li><a href="">Instagram</a></li>
            <li><a href="">Facebook</a></li>
            <li><a href="">Discord</a></li>
            <li><a href="">X</a></li>
          </ul>
        </div>
      </div>

      <div class="footerRow">
        <span style="font-weight: bold;"><p>© 2025 League Of Legends TCG. Tous droits réservés.</p></span>
      </div>
      
      <div class="footerRow" id="legalRow">
        <div class="aligncenter">
          <a href="">Politique de confidentialité</a>
        </div>
        <div class="aligncenter">
          <a href="">Conditions générales</a>
        </div>
        <div class="aligncenter">
          <a href="">Mentions légales</a>
        </div>
      </div>

  </footer>

