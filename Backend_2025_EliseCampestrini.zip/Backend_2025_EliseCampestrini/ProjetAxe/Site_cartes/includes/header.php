    <!-- NAVBAR -->
    <?php require_once(__DIR__ . '/../src/connexion.php'); ?>

    <nav>
        <div>
            <img src="/Backend_2025_EliseCampestrini/ProjetAxe/Site_cartes/img/logo.png" alt="logo">
        </div>

            <div id="MenuLink">
                <a href="/Backend_2025_EliseCampestrini/ProjetAxe/Site_cartes/index.php">Accueil</a>
                <a href="/Backend_2025_EliseCampestrini/ProjetAxe/Site_cartes/cards.php">Parcourir les cartes</a>
            

            <?php

                // Si notre utilisateur est déjà connecté
                if(isset($_SESSION["id_user"])) 
                {
                    echo "<a href='/Backend_2025_EliseCampestrini/ProjetAxe/Site_cartes/CRUDCreateCards/CardsView.php'>Mon Profile</a>";
                }
                else
                {
                    echo "<a href='/Backend_2025_EliseCampestrini/ProjetAxe/Site_cartes/form.php'>Connexion / Inscription</a>";
                }
            ?>
            
        </div>
    </nav>

