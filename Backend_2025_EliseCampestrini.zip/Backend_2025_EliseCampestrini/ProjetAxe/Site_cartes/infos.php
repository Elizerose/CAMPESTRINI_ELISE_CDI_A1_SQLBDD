<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Découvre notre jeu de cartes à collectionner inspiré de l'univers de League of Legends ! Collectionne des cartes, construit des decks et affronte des joueurs du monde entier. Rejoignez l'aventure dès maintenant !">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="img/icons/collection.png"/>
    <link href="https://db.onlinewebfonts.com/c/12420e8c141ca7c3dff41de2d59df13e?family=Beaufort+for+LOL+Bold" rel="stylesheet"> 
    <link href="https://db.onlinewebfonts.com/c/12420e8c141ca7c3dff41de2d59df13e?family=Beaufort+for+LOL+Light" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" /> <!-- Swiper js -->
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/infosPage.css">
    <link rel="stylesheet" href="css/cards.css">
    <title>League Of Legends TCG - Collectionne, Échange, Combat !</title>


</head>

	<body>
		
		<!-- HEADER -->
		<header>
			<!-- On ajoute notre header -->
			<?php include 'includes/header.php'; ?>
		</header>

        <?php

        include 'src/createCard.php';

        // Si on get le champion correpondant a la page dans l'url
        if (isset($_GET['page'])) 
        {
            $page = $_GET['page'];
        } 
        else 
        {
            header('Location: cards.php'); // le parametre est pas trouvé : on redirige a la page champions
            exit(); // Toujours mettre exit après une redirection
        }

        // on recupere une url de l'api qui donne des infos precises sur le champion en parametre
        $url = 'https://ddragon.leagueoflegends.com/cdn/15.7.1/data/fr_FR/champion/' .$page .'.json';
        $response = file_get_contents($url);
        if ($response === FALSE)
        {
            http_response_code(500);
            echo json_encode(['error' => 'Erreur lors de la récupération des données.']);
            exit;
        }
        else 
        {
            // on recupere la data
            $data = json_decode($response,true);
        }

        // on définit le champion
        $champion = $data['data'][$page];


        // On affiche le contenu correspondant
        echo 
        "
        
        <section>

            
            <div id='ChampHeader'>

                <img src='https://ddragon.leagueoflegends.com/cdn/img/champion/splash/" .$champion['id'] ."_0.jpg' class='champImg'>

            </div>
            <div id='ChampInfos'>

                <div id='champPres'>

                    <h1>" .$page ."</h1>
                    
                    <ul class='champ_Tags displayFlex'>
                        " ;
                            foreach ($champion['tags'] as $tag)
                            {
                                echo "<li><img src='img/icons/role_icon_" .$tag .".png' alt=''></li>";
                            }
                        echo "

                    </ul>
                
                    <h2>" .$champion['title'] ."</h2>

                    <img src='img/separator/t1HeaderDivider.png' alt='separateur' class='separator'>
                    
                </div>


                <div id='Champ' class='displayFlex'>

                    <div id='ChampDesc'>
                
                        <h3>Description</h3>

                        <p>" .$champion['lore'] ."</p>

                    </div>
                    <div id='ChampStats'>
                        <ul>
                            <li>
                                <i class='fa-regular fa-star-half-stroke' style='color: #ae914b;'></i>
                                <p>DIFFICULTÉ</p>
                                <p class='stats'>".$champion['info']['difficulty'] ."</p>
                            </li>
                            <li>
                                <i class='fa-solid fa-heart' style='color: #ae914b;'></i>
                                <p>HP</p>
                                <p class='stats'>".$champion['stats']['hp'] ."</p>
                            </li>
                        </ul>
                        <ul>
                            <li>
                                <i class='fa-solid fa-hand-fist' style='color: #ae914b;'></i>
                                <p>ATTAQUE</p>
                                <p class='stats'>".$champion['info']['attack'] ."</p>
                            </li>
                            <li>
                                <i class='fa-solid fa-hat-wizard' style='color: #ae914b;'></i>
                                <p>MAGIE</p>
                                <p class='stats'>".$champion['info']['magic'] ."</p>
                            </li>
                            <li>
                                <i class='fa-solid fa-shield-halved' style='color: #ae914b;'></i>
                                <p>DEFENSE</p>
                                <p class='stats'>".$champion['info']['defense'] ."</p>
                            </li>
                        </ul>
                    </div>
                    <div id='ChampCard'>

                        ";
                        // fonction de createCard.php qui affiche la carte champion
                        CreateCard($champion,FALSE);
                        echo "

                    </div>

                </div>
                
            </div>
            







        </section>       
        
        
        
        
        
        
        "

        ?>

        



        <?php include 'includes/footer.php' ?>


    </body>
</html>

<script src="https://kit.fontawesome.com/c2ae8767dc.js" crossorigin="anonymous"></script>