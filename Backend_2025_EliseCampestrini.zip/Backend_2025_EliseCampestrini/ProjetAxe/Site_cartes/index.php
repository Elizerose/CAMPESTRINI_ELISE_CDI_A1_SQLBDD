<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="Découvre notre jeu de cartes à collectionner inspiré de l'univers de League of Legends ! Collectionne des cartes, construit des decks et affronte des joueurs du monde entier. Rejoignez l'aventure dès maintenant !">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" type="image/png" href="img/icons/collection.png"/>
    <link href="https://db.onlinewebfonts.com/c/12420e8c141ca7c3dff41de2d59df13e?family=Beaufort+for+LOL+Bold" rel="stylesheet"> 
    <link href="https://db.onlinewebfonts.com/c/12420e8c141ca7c3dff41de2d59df13e?family=Beaufort+for+LOL+Light" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" /> <!-- Swiper js -->
    <link rel="stylesheet" href="css/style.css">
    <title>League Of Legends TCG - Collectionne, Échange, Combat !</title>
</head>

	<body>

		<!-- HEADER -->
		<header id="landingPageHeader">


			<!-- On ajoute notre header -->
			<?php include 'includes/header.php'; ?>

			<div id="headerInfos">
				<h1>Forge ta légende</h1>
				<p>Lève ton deck et entre dans la légende !</p>
				<button id="StartAdventureButton">COMMENCER L'AVENTURE  →</button>
			</div>

			<img src="img/CardsHeader.png" alt="cartes" id="HeaderCardsImg">

		</header>


		<!-- SECTION CHIFFRES -->
		<section id="SectionChiffres">
			<div>
				<img src="img/icons/users.png" alt="icon utilisateurs">
				<p>+ 10,000 utilisateurs actifs</p>
			</div>
			<div>
				<img src="img/icons/feedbacks.png" alt="icon avis">
				<p>4.9/5 Avis positifs</p>
			</div>
			<div>
				<img src="img/icons/cards.png" alt="icon cartes">
				<p>+ 500 Cartes à Collectionner</p>
			</div>
		</section>

		<!-- SECTION A PROPOS -->
		<section id="APropos">
				<div>
					<h2>A PROPOS</h2>
					<p>
						<span style="font-weight: bold;">LeagueOfLegends<span style="color:#AE914B">TCG</span></span> est une plateforme dédiée aux passionnés de jeux de cartes à collectionner.
						<br>
						Notre plateforme est 100% gratuite et accessible depuis n'importe quel appareil.
						<br>
						Plonge dans l'univers de Runeterra et collectionne tes cartes préférées pour créer des decks stratégiques. 
						Que tu soit un collectionneur ou un joueur compétitif, cette plateforme est faite pour toi ! 
						<br>
						Explore, collectionne et apprend à maîtriser l'art de la stratégie dans l'univers mythique de League of Legends.
					</p>
				</div>
				<img src="img/TF.png" alt="Twisted Fate">
				
		</section>

		<!-- SECTION FEATURES -->
		<section id="features">

				<h2>FEATURES</h2>

				<!-- Premiere ligne -->
				<div id="contentRowFeatures">
					<article>
						<img src="img/icons/collection.png" alt="icon collection">
						<h3>Collectionne des cartes</h3>
						<p>Ouvre des boosters ou rend toi dans la boutique pour enrichir ta collection. Rassemble des champions, sorts et objets emblématiques de Runeterra et crée ton arsenal de cartes !</p>
					</article>
					<article>
						<img src="img/icons/echange.png" alt="icon echange">
						<h3>Échange avec la communauté</h3>
						<p>Échange tes cartes avec tes amis ou d'autres joueurs de la communauté pour compléter ta collection et compléter tes decks.</p>
					</article>
					<article>
						<img src="img/icons/deck.png" alt="icon deck">
						<h3>Construis tes decks</h3>
						<p>Crée des decks personnalisées avec des cartes qui s’accordent à ton style de jeu. Combine champions, sorts et objets pour prendre l’avantage sur tes adversaires.</p>
					</article>
				</div>

				<!-- deuxieme ligne -->
				<div id="contentRowFeatures">
					<article>
						<img src="img/icons/combats.png" alt="icon combats">
						<h3>Défie d'autres joueurs</h3>
						<p>Affronte des joueurs du monde entier dans des duels palpitants en ligne ou entre amis.</p>
					</article>
					<article>
						<img src="img/icons/tournois.png" alt="icon tournois">
						<h3>Participe aux tournois</h3>
						<p>Rejoins des tournois et prouve ta maîtrise du jeu. <br> Grimpe dans les classements, remporte des récompenses et inscris ton nom parmi les légendes de Runeterra !</p>
					</article>
				</div>
			
		</section>

		<!-- SECTION NOUVEAUTES -->
		<!-- Swiper -->
		<section id="nouveautes">
				<h2>NOUVEAUTES</h2>

				<div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff" class="swiper mySwiper">
					<div class="parallax-bg" style="
						background-image: url(img/bg/CardsList.jpg);
						" data-swiper-parallax="-20%"></div>
					<div class="swiper-wrapper">
				
					<!-- Contenu slide 1 -->
					<div class="swiper-slide">
						<img src="img/NewYear.png" alt="packs d'evenement avec smolder" data-swiper-parallax="-50" id="imgEvent">
						<div class="swiper-infos-slide">
						<div class="title" data-swiper-parallax="-250">Célèbre le nouvel an lunaire avec League Of Legends TCG !</div>
						<div class="text" data-swiper-parallax="-100">
							<p>
								Célébre la nouvelle année lunaire et participe à un événement saisonnier exclusif !
								<br>
								Collectionne des cartes festives et débloque des récompenses limitées !
							</p>
						</div>
						<button>En savoir plus →</button>
						</div>
					</div>
				
					<!-- Contenu slide 2 -->
					<div class="swiper-slide">
						<div class="swiper-infos-slide">
						<div class="title" data-swiper-parallax="-250">Arcane débarque !</div>
						<div class="text" data-swiper-parallax="-100">
						<p>
							De nouvelles cartes arrivent !
							<br>
							Plonge dans l'univers de Piltover et Zaun avec des cartes inédites inspirées d'Arcane !
						</p>
						</div>
						<button>En savoir plus →</button>
						</div>
						<img src="img/ArcanesDeck.png" alt="Jinx et Vi avec leurs cartes Arcanes" data-swiper-parallax="-50" id="imgArcane">
					</div>
				
					<!-- Contenu slide 3 -->
					<div class="swiper-slide">
						<div class="swiper-infos-slide">
						<div class="title" data-swiper-parallax="-250">Lancement du Tournoi "Ligue des Champions"</div>
						<div class="text" data-swiper-parallax="-100">
						<p>
							Inscris-toi dès maintenant au tournoi exclusif mondial, disponible pour une durée limitée.
							Affronte des joueurs du monde entier et tente de décrocher des récompenses exclusives et limitées.
						</p>
						</div>
						<button>En savoir plus →</button>
					</div>
					<img src="img/Fight.png" alt="Champions qui courent" data-swiper-parallax="-50" id="imgTournoi">
					</div>
				
					</div>
					<div class="swiper-button-next"></div>
					<div class="swiper-button-prev"></div>
					<div class="swiper-pagination"></div>
				</div>

		</section>

		<!-- SECTION AVIS -->
		<section id="avis">

				<h2>AVIS DE LA COMMUNAUTE</h2>

				<div id="AvisGroup">
				<div class="avisContent">
					<p class="avisText">"Un jeu de cartes incroyable qui retranscrit parfaitement l'univers de League of Legends. Je recommande vivement !"</p>
					<p class="AvisUserName">~ PentakillKing</p>
				</div>
				<div class="avisContent">
					<p class="avisText">"Etant un grand fan de LOL, je recherchais justement un jeu de collection et j'ai découvert cette plateforme, un vrai bonheur."</p>
					<p class="AvisUserName">~ DeckWarrior92</p>
				</div>
				<div class="avisContent">
					<p class="avisText">"Une communauté active et passionnée ! Cette plateforme est de loin ma préférée. Les mises à jour régulières et les tournois exclusifs garantissent une expérience toujours renouvelée !"</p>
					<p class="AvisUserName">~ MainYumiUwU</p>
				</div>
				</div>

				<button>Tout les avis →</button>

		</section>

		<!-- On ajoute notre footer -->
		<?php include 'includes/footer.php'; ?>

		<!-- SWIPER JS -->

		<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

		<script>
			var swiper = new Swiper(".mySwiper", {
				speed: 600,
				parallax: true,
				pagination: {
				el: ".swiper-pagination",
				clickable: true,
				},
				navigation: {
				nextEl: ".swiper-button-next",
				prevEl: ".swiper-button-prev",
				},
			});
		</script>

	</body>
</html>