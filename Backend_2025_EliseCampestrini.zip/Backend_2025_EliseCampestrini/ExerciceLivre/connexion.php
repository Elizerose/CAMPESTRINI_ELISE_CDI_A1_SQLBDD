<?php

$host = 'localhost';
$dbname = 'catalogue_livres';
$username = 'root';
$port = 3306;
$password = '';

// on récupere notre bdd
try {
    $pdo = new PDO("mysql:host=$host; port=$port; dbname=$dbname; charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} 
catch (PDOException $e) 
{
    die("Erreur de connexion : " . $e->getMessage());
}