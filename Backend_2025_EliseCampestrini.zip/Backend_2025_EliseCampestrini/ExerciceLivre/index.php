<?php

require_once("connexion.php"); // récupérer la connexion à la base de données pour y accéder


$stmt = $pdo->query("SELECT * FROM livres WHERE publication_year >= 2000 ORDER BY author"); // PDO STATEMENT
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);


?>



<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <h1>Les livres de ma base de données</h1>

    <table border="1">
        <thead>
            <td>Titre</td>
            <td>Auteur</td>
            <td>Année de publication</td>
            <td>Disponibilité</td>
        </thead>

        <tbody>

            <?php

            foreach ($books as $key => $book) {
                echo "<tr>";
                echo "<td>" . $book["title"] . "</td>";
                echo "<td>" . $book["author"] . "</td>";
                echo "<td>" . $book["publication_year"] . "</td>";
                echo "<td>" . ($book["available"]  ? "oui" : "non") . "</td>";
                echo "</tr>";
            }

            ?>

        </tbody>
    </table>

</body>

</html>